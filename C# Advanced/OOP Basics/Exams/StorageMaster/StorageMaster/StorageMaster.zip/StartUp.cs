﻿using StorageMaster.Core;
using System;
using System.Collections.Generic;

namespace StorageMaster
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
