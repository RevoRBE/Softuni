﻿using StorageMaster.Entities.Products;
using StorageMaster.Entities.Vehicles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StorageMaster.Entities.Storages
{
    public abstract class Storage
    {
        private readonly List<Product> products;
        private readonly List<Vehicle> garage;

        public Storage(string name, int capacity, int garageSlots, IEnumerable<Vehicle> vehicles)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.GarageSlots = garageSlots;

            this.garage = new List<Vehicle>();
            this.products = new List<Product>();

            InitalizeGarage(vehicles);
        }

        public string Name { get; }
        
        public int Capacity { get; }

        public int GarageSlots { get; }
        
        public IReadOnlyCollection<Vehicle> Garage => this.garage.AsReadOnly();

        public IReadOnlyCollection<Product> Products => this.products.AsReadOnly();

        private void InitalizeGarage(IEnumerable<Vehicle> vehicles)
        {
            foreach (var item in vehicles)
            {
                this.garage.Add(item);
            }
        }

        public bool IsFull => Capacity <= this.products.Sum(p => p.Weight);

        public Vehicle GetVehicle(int garageSlot)
        {
            if (garageSlot - 1 > this.GarageSlots)
            {
                throw new InvalidOperationException("Invalid garage slot!");
            }
            return this.garage[garageSlot];
        }

        public int SendVehicleTo(int garageSlot, Storage deliveryLocation)
        {
            Vehicle vehicle = GetVehicle(garageSlot);
            if (deliveryLocation.GarageSlots <= deliveryLocation.Garage.Count || deliveryLocation.Garage.Any(v => v == null))
            {
                throw new InvalidOperationException("No room in garage!");
            }
            this.garage.Remove(vehicle);
            for (int i = 0; i < deliveryLocation.garage.Count(); i++)
            {
                if (deliveryLocation.garage[i] == null)
                {
                    deliveryLocation.garage[i] = vehicle;
                    return i;
                }
            }
            deliveryLocation.garage.Add(vehicle);
            return deliveryLocation.garage.Count();
        }

        public int UnloadVehicle(int garageSlot)
        {
            int count = 0;
            if (this.Products.Any(p => p == null))
            {
                throw new InvalidOperationException("Storage is full!");
            }
            Vehicle vehicle = GetVehicle(garageSlot);
            foreach (var item in vehicle.Trunk)
            {
                if (!this.IsFull)
                {
                    Product product = vehicle.Unload(item);
                    this.products.Add(product);
                    count++;
                }
            }
            return count;
        }
    }
}
