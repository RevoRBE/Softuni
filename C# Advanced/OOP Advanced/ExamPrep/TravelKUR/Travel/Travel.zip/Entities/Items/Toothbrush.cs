﻿namespace Travel.Entities.Items
{
	public class Toothbrush : Item
	{
		public Toothbrush()
			: base(value: 3)
		{
		}
	}
}