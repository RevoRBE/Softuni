﻿public interface IReader
{
    string ReadLine();
}